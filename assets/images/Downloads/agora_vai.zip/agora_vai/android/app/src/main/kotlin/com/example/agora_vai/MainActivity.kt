package com.example.agora_vai

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
